//
//  ViewController.swift
//  COMP399_teamProject
//
//  Created by Harsh Shastri on 11/15/18.
//  Copyright © 2018 Harsh Shastri. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var howToPlayButton: UIButton!
    @IBOutlet weak var exitButton1: UIButton!
    @IBAction func exitButtonClicked(_ sender: Any) {
        exit(0);
    }
    
    @IBAction func instructionButtonPressed(_ sender: Any)
    {
        
        let helpController = UIAlertController(title: "How To Play", message: "Match all cards to end the game." + "\nTry to finish it as soon as possible!", preferredStyle: UIAlertController.Style.alert)
        
        let okayAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
        
        helpController.addAction(okayAction)
        
        present(helpController, animated:true, completion: nil)
        
        
    }
    
    func addBorders(_ button: UIButton){
        button.backgroundColor = .clear
        button.layer.cornerRadius = 5
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.white.cgColor
    }
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        addBorders(startButton)
        addBorders(howToPlayButton)
        addBorders(exitButton1)
    }


}

