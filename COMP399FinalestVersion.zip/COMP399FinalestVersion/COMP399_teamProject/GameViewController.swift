//
//  GameViewController.swift
//  COMP399_teamProject
//
//  Created by Harsh Shastri on 11/15/18.
//  Copyright © 2018 Harsh Shastri. All rights reserved.
//

import UIKit
import AudioToolbox

let blueImg = "bluecard.png"
let redImg = "redcard.png"
let cardArray = ["diamond.png", "spade.png", "clover.png", "heart.png"] //stores suites


class Card{
    var suit: String
    var rank: String
    init(suit : String, rank : String) {
        self.suit = suit
        self.rank = rank
    }
    
    func getNum()->String{
        return self.rank
    }
    
    func getSuit()->String{
        return self.suit
    }
}


class GameViewController: UIViewController
{
    
    
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    
    
    @IBOutlet weak var card1: UIButton!
    
    @IBOutlet weak var card2: UIButton!
    
    @IBOutlet weak var card3: UIButton!
    
    @IBOutlet weak var card4: UIButton!
    
    @IBOutlet weak var card5: UIButton!
    
    @IBOutlet weak var card6: UIButton!
    
    @IBOutlet weak var card7: UIButton!
    
    @IBOutlet weak var card8: UIButton!
    
    @IBAction func resetClicked(_ sender: Any) {
        resetGame()
    }
    
    var mycards: [UIButton] = [UIButton]() //array used for checking if the game has been won
    
    //card objects declared
    var displayCard1 : Card?
    var displayCard2 : Card?
    var displayCard3 : Card?
    var displayCard4 : Card?
    var displayCard5 : Card?
    var displayCard6 : Card?
    var displayCard7 : Card?
    var displayCard8 : Card?
    
    //keeps track of which cards are being compared and the previous image & buttons
    var cardClicked1 : Card?
    var cardClicked2 : Card?
    var prevImg1 : UIImage?
    var prevImg2 : UIImage?
    var buttonClicked1 : UIButton?
    var buttonClicked2 : UIButton?

    var finishTime = "" //variable in which the finish time will be recorded
    
    @IBOutlet weak var stopWatchLabel: UILabel!
    
    func dismissViewController()
    {
        dismiss(animated: true, completion: nil)
    }
    
    /*
     * Variable for stopWatch
     */
    var counter = 0.00
    //using Objective-C Timer()
    var stopWatch = Timer()
    var isRunning = false
    
    func beginStopWatch(_ sender: AnyObject) {
        if(isRunning)
        {
            return
        }
        
        //when the button or card is flipped
        //card.isFlipped = false
        
        //@objc inference depreciation using #selector
        stopWatch = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(updateStopWatch), userInfo: nil, repeats: true)
        isRunning = true
    }
    
    //function that will add seconds to the stopWatch 
    @objc func updateStopWatch()
    {
        counter = counter + 0.1
        
        stopWatchLabel.text = String(format: "%.2f", counter)
    }
    
    func resetTimer(_ sender: AnyObject)
    {
        //set all buttons/cards to unflipped since game is restarting
        //card.isFlipped = false
        
        stopWatch.invalidate()
        isRunning = false
        counter = 0.0
        stopWatchLabel.text = String(counter)
    }
    
    @IBAction func backButtonPressed(_ sender: Any)
    {
        //sets up alert to check if user really wants to quit
        let backButtonController = UIAlertController(title: "Hold up!", message: "Do you wish to quit?", preferredStyle: UIAlertController.Style.alert)
        
        let yesAlert = UIAlertAction(title: "Yes", style: UIAlertAction.Style.destructive, handler: {(action:UIAlertAction!)->Void in self.performSegue(withIdentifier: "goBack", sender: self)})
        
        let noAlert = UIAlertAction(title: "No", style: UIAlertAction.Style.default, handler: nil)
        
        backButtonController.addAction(yesAlert)
        backButtonController.addAction(noAlert)
        
        present(backButtonController, animated: true, completion: nil)
    }
    
    func setCardImage(_ card : Card, _ cardButton: UIButton){
        //sets the card image to the button
        cardButton.setTitle(card.getNum(), for: UIControl.State.normal)
        cardButton.setBackgroundImage(UIImage(named: card.getSuit()), for: UIControl.State.normal)
    }
    
    //compares card values
    func ifCardsMatch(_ this : Card, _ other : Card) -> Bool{
        if (this.getSuit() == other.getSuit() && this.getNum() == other.getNum()){
            return true
        }
        else{
            return false
        }
    }
    
    
    var clickCount = 0 //keeps track of button clicks
    var mismatchCount = 0 //keeps track of failed attempts to match
    
    @IBAction func cardAction(_ sender: UIButton) {
        clickCount+=1
        var currentCardButton: UIButton?
        //only performs when click count is less than or equal to two
        if clickCount <= 2{
            switch (sender){
            case card1:
                currentCardButton = card1
            case card2:
                currentCardButton = card2
            case card3:
                currentCardButton = card3
            case card4:
                currentCardButton = card4
            case card5:
                currentCardButton = card5
            case card6:
                currentCardButton = card6
            case card7:
                currentCardButton = card7
            case card8:
                currentCardButton = card8
                
            default:
                currentCardButton = nil
            }
        
            //makes sure that you can't click the same flipped card
            if !(currentCardButton == buttonClicked1 || currentCardButton == buttonClicked2){
                let currentCard = returnCurrentCard(currentCardButton!)
                
                //asigns previous image and button of each card clicked to a var and disables or enables user interation based on click count for bug control
                if clickCount == 1{
                    prevImg1 = currentCardButton?.backgroundImage(for: UIControl.State.normal)
                    buttonClicked1 = currentCardButton!
                    self.view.isUserInteractionEnabled = true
                }else if(clickCount == 2){
                    prevImg2 = currentCardButton?.backgroundImage(for: UIControl.State.normal)
                    buttonClicked2 = currentCardButton!
                    self.view.isUserInteractionEnabled = false
                }
                setCardImage(currentCard, currentCardButton!)
            }
            
            //checks if cards matched based on clickCount
            if clickCount == 1{
                cardClicked1 = returnCurrentCard(currentCardButton!)
            }else if clickCount == 2{
                //compares cardClicked1 and cardClicked2
                cardClicked2 = returnCurrentCard(currentCardButton!)
                
                //delays the comparison by one second so user can see the card flipped
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute:
                    {
                    if !(self.ifCardsMatch(self.cardClicked1!, self.cardClicked2!))
                    {
                        self.buttonClicked1?.setBackgroundImage(self.prevImg1, for: UIControl.State.normal)
                        self.buttonClicked1?.setTitle("", for: UIControl.State.normal)
                        self.buttonClicked2?.setBackgroundImage(self.prevImg2, for: UIControl.State.normal)
                        self.buttonClicked2?.setTitle("", for: UIControl.State.normal)
                        self.buttonClicked1 = nil
                        self.buttonClicked2 = nil
                        self.mismatchCount+=1
                        self.view.isUserInteractionEnabled = true
                        self.wrongSoundAlert()
                        
                    }
                    else
                    {
                        self.view.isUserInteractionEnabled = true
                        self.correctSoundAlert()
                    }
                })
                
                clickCount = 0 //resets click count after 2 cards are compared
               
            }
            
            //checks if winning condition has been met and displays alert
            if (checkIfCardsFaceUp()) {
                //finishTime = stopWatchLabel.text! //assigns the time that the user completed the game
                
                let alertController = UIAlertController(title: "Congratulations", message: "You matched all the cards!", preferredStyle:UIAlertController.Style.alert)
                
                let defaultAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {(action:UIAlertAction!)->Void in self.performSegue(withIdentifier: "showScore", sender: self)})
                
                alertController.addAction(defaultAction)
                present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    //returns the card object of a particular button
    func returnCurrentCard(_ cardButton : UIButton) -> Card{
        switch(cardButton){
        case card1:
            return displayCard1!
        case card2:
            return displayCard2!
        case card3:
            return displayCard3!
        case card4:
            return displayCard4!
        case card5:
            return displayCard5!
        case card6:
            return displayCard6!
        case card7:
            return displayCard7!
        case card8:
            return displayCard8!
        default:
            return displayCard1!
        }
    }
    
    func initializeCards(_ deck : [Card]){
        //four initial random numbers all distinct
        let randomNum1 = Int(arc4random_uniform(51))
        var randomNum2 = Int(arc4random_uniform(51))
        while (randomNum2 == randomNum1){
            randomNum2 = Int(arc4random_uniform(51))
        }
        var randomNum3 = Int(arc4random_uniform(51))
        while (randomNum3 == randomNum2 && randomNum3 == randomNum1){
            randomNum3 = Int(arc4random_uniform(51))
        }
        var randomNum4 = Int(arc4random_uniform(51))
        while (randomNum4 == randomNum2 && randomNum4 == randomNum3 && randomNum4 == randomNum1 ){
            randomNum4 = Int(arc4random_uniform(51))
        }
        
        //four distinct cards
        displayCard1 = deck[randomNum1]
        displayCard3 = deck[randomNum2]
        displayCard5 = deck[randomNum3]
        displayCard7 = deck[randomNum4]
        
        let randomNumber = Int(arc4random_uniform(3) + 1)
        
        //create 4 random different combinations
        if (randomNumber == 1){
            displayCard2 = displayCard1
            displayCard4 = displayCard3
            displayCard6 = displayCard5
            displayCard8 = displayCard7
        }
            
        else if (randomNumber == 2){
            displayCard2 = displayCard3
            displayCard4 = displayCard5
            displayCard6 = displayCard7
            displayCard8 = displayCard1
        }
            
        else if (randomNumber == 3){
            displayCard2 = displayCard5
            displayCard4 = displayCard7
            displayCard6 = displayCard1
            displayCard8 = displayCard3
        }
            
        else if (randomNumber == 4){
            displayCard2 = displayCard7
            displayCard4 = displayCard1
            displayCard6 = displayCard3
            displayCard8 = displayCard5
        }
    }
    
    //mimics a game reset by reinitializing starting values
    func resetGame(){
        let ranks = ["2","3","4","5","6","7","8","9","10","A","J","K","Q"]
        var deck: [Card] = []
        for i in 0..<ranks.capacity{
            for j in 0..<cardArray.capacity{
                deck.append(Card(suit: cardArray[j], rank: ranks[i]))
            }
        }
        
        initializeCards(deck)
        
        //set initial button images
        setButtonImage(card1, blueImg)
        card1.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card2, redImg)
        card2.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card3, blueImg)
        card3.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card4, redImg)
        card4.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card5, redImg)
        card5.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card6, blueImg)
        card6.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card7, redImg)
        card7.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card8, blueImg)
        card8.setTitle(nil, for: UIControl.State.normal)
        
        resetTimer(self)
        beginStopWatch(self)
        
        clickCount = 0
        mismatchCount = 0
    }

    //checks if cards have an absent title value, no title value means the card is face down
    func checkIfCardsFaceUp() -> Bool {
        var flag = 0
       for i in 0...7{
          if (mycards[i].currentTitle == "" || mycards[i].currentTitle == nil){
             flag = 1
            }
        }
      if flag == 1{
          return false
       }else{
            finishTime = stopWatchLabel.text!
            stopWatch.invalidate()
            stopWatchLabel.text = finishTime
            return true
       }
    }
    
    /*
     * Two following functions below takes care of the sounds when you get correct or wrong
     */
    func correctSoundAlert()
    {
        var soundID: SystemSoundID = 0
        
        let soundFile: String = Bundle.main.path(forResource: "correctBuzzer", ofType: "wav")!
        
        let soundURL: URL = URL(fileURLWithPath: soundFile)
        
        //sound conversion of the dataset -> CFURL
        AudioServicesCreateSystemSoundID(soundURL as CFURL, &soundID)
        
        AudioServicesPlaySystemSound(soundID)
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
    }
    
    func wrongSoundAlert()
    {
        var soundID: SystemSoundID = 0
        
        let soundFile: String = Bundle.main.path(forResource: "wrongBuzzer", ofType: "wav")!
        
        let soundURL: URL = URL(fileURLWithPath: soundFile)
        
        //sound conversion of the dataset -> CFURL
        AudioServicesCreateSystemSoundID(soundURL as CFURL, &soundID)
        
        AudioServicesPlaySystemSound(soundID)
        
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
    }
    
    
    override func viewDidLoad()
    {
        addBorders(backButton)
        addBorders(resetButton)

        self.mycards = [self.card1, self.card2, self.card3, self.card4, self.card5, self.card6, self.card7, self.card8]
        //stores card buttons
        
        let ranks = ["2","3","4","5","6","7","8","9","10","A","J","K","Q"]
        
        
        var deck: [Card] = []
        
        //fill in the deck
        for i in 0..<ranks.capacity{
            for j in 0..<cardArray.capacity{
                deck.append(Card(suit: cardArray[j], rank: ranks[i]))
            }
        }
        
        initializeCards(deck) //initialize cards
        beginStopWatch(self)
        
        
        super.viewDidLoad()
        stopWatchLabel.text = String(counter)
        
        /*
         * When the gameView is loaded, the stopwatch does not run until the player clicks one of the cards. So initially isFlipped wil be false.
         */
        // I would say something like...
        // card.isFlipped = false
        
        setButtonImage(card1, blueImg)
        card1.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card2, redImg)
        card2.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card3, blueImg)
        card3.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card4, redImg)
        card4.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card5, redImg)
        card5.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card6, blueImg)
        card6.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card7, redImg)
        card7.setTitle(nil, for: UIControl.State.normal)
        
        setButtonImage(card8, blueImg)
        card8.setTitle(nil, for: UIControl.State.normal)
    }
    
    //function that addes borders to buttons
    func addBorders(_ button: UIButton)
    {
        button.backgroundColor = .clear
        button.layer.cornerRadius = 5
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.white.cgColor
    }
    
    func setButtonImage(_ button: UIButton, _ img: String) {
        button.setBackgroundImage(UIImage(named: img), for: UIControl.State.normal)
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
