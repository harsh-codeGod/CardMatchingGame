//
//  ScoreViewController.swift
//  COMP399_teamProject
//
//  Created by Harsh Shastri on 12/4/18.
//  Copyright © 2018 Harsh Shastri. All rights reserved.
//

import UIKit

class ScoreViewController: UIViewController {

    @IBOutlet weak var timeOutlet: UITextView!
    @IBOutlet weak var mismatchOutlet: UITextView!
    @IBOutlet weak var playAgainButton: UIButton!
    @IBOutlet weak var quitButton: UIButton!
    
    //resets the game when clicked
    @IBAction func playAgainClicked(_ sender: Any) {
        (presentingViewController as! GameViewController).resetGame()
    }
    
    //exits application when clicked
    @IBAction func quitClicked(_ sender: Any) {
        exit(0)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //sets the mismatch count
        mismatchOutlet.text = "\((presentingViewController as! GameViewController).mismatchCount)"
        
        //sets the finish time
        timeOutlet.text = (presentingViewController as! GameViewController).finishTime
        
        //adds borders to the buttons
        addBorders(playAgainButton)
        addBorders(quitButton)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

     
    }
    
    //adds white border around buttons
    func addBorders(_ button: UIButton){
        button.backgroundColor = .clear
        button.layer.cornerRadius = 5
        button.layer.borderWidth = 1
        button.layer.borderColor = UIColor.white.cgColor
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
